cwlVersion: v1.2
class: CommandLineTool
baseCommand: "false"
inputs: []
outputs: []
