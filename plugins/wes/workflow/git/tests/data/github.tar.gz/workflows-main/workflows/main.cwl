cwlVersion: v1.2
class: Workflow
inputs: []
outputs: []
steps:
  step:
    run: tools/step.cwl
    in: []
    out: []
